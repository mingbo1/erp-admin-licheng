<?php

return [
    'Temp_name'        => '模板名称',
    'Purchase_code'    => '单据编号',
    'Purchase_time'    => '单据日期',
    'Business_type'    => '业务类型:1=拆卸单',
    'Money'            => '费用',
    'Remark'           => '备注',
    'Preparation_id'   => '制单人',
    'Operation_id'     => '最后操作人',
    'Examine_id'       => '审核人',
    'Examine_status'   => '审核状态',
    'Examine_status 0' => '未审核',
    'Examine_status 1' => '已审核',
    'Examine_time'     => '审核时间',
    'Print_num'        => '打印次数',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间',
    'Admin.username'   => '用户名'
];
