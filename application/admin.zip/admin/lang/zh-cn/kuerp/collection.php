<?php

return [
    'Purchase_code'    => '单据编号',
    'Purchase_time'    => '单据时间',
    'Customers_id'     => '客户',
    'Money'            => '收款合计',
    'Write_off'        => '核销金额',
    'Discount'         => '整单折扣',
    'Advance'          => '预收款',
    'Staff_member_id'  => '收款人',
    'Remarks'          => '备注',
    'Preparation_id'   => '制单人',
    'Examine_id'       => '审核人',
    'Operation_id'     => '最后操作人',
    'Examine_time'     => '审核时间',
    'Examine_status'   => '审核状态',
    'Examine_status 0' => '未审核',
    'Examine_status 1' => '已审核',
    'Print_num'        => '打印次数',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间',
    'Admin.username'   => '用户名',
    'Staffmember.name' => '职员名称'
];
