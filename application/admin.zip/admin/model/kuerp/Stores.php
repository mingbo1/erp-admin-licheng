<?php

namespace app\admin\model\kuerp;

use think\Model;
use traits\model\SoftDelete;

class Stores extends Model
{
    // 表名
    protected $name = 'kuerp_stores';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';

    // 追加属性
    protected $append = [
        'status_text',
        'store_type_text'
    ];



    public function getStatusList()
    {
        return ['0' => __('Status 0'), '1' => __('Status 1')];
    }

    public function getStoreTypeList()
    {
        return ['part' => __('Store_type part'), 'general' => __('Store_type general')];
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getStoreTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['store_type']) ? $data['store_type'] : '');
        $list = $this->getStoreTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
